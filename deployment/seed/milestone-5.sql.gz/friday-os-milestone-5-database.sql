--
-- PostgreSQL database dump
--

-- Dumped from database version 16.6
-- Dumped by pg_dump version 16.6

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: comms; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA comms;


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: messages; Type: TABLE; Schema: comms; Owner: -
--

CREATE TABLE comms.messages (
    id integer NOT NULL,
    conversation_id text NOT NULL,
    channel text NOT NULL,
    role text NOT NULL,
    sender text,
    content text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: messages_id_seq; Type: SEQUENCE; Schema: comms; Owner: -
--

CREATE SEQUENCE comms.messages_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: messages_id_seq; Type: SEQUENCE OWNED BY; Schema: comms; Owner: -
--

ALTER SEQUENCE comms.messages_id_seq OWNED BY comms.messages.id;


--
-- Name: agent_trust; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.agent_trust (
    id integer NOT NULL,
    agent_id character varying(64) NOT NULL,
    action_type character varying(32) NOT NULL,
    clean_approvals integer NOT NULL,
    auto_approve boolean NOT NULL,
    updated_at timestamp without time zone
);


--
-- Name: agent_trust_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.agent_trust_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: agent_trust_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.agent_trust_id_seq OWNED BY public.agent_trust.id;


--
-- Name: approvals; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.approvals (
    id character varying(64) NOT NULL,
    agent_id character varying(64),
    invocation_id character varying(64),
    action_type character varying(32),
    title character varying(256),
    task text,
    context json,
    status character varying(16) NOT NULL,
    approver character varying(128),
    note text,
    created_at timestamp without time zone NOT NULL,
    resolved_at timestamp without time zone
);


--
-- Name: audit_events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.audit_events (
    id integer NOT NULL,
    "timestamp" timestamp without time zone NOT NULL,
    event_type character varying(64) NOT NULL,
    agent_id character varying(64),
    invocation_id character varying(64),
    payload json,
    notes text
);


--
-- Name: audit_events_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.audit_events_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: audit_events_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.audit_events_id_seq OWNED BY public.audit_events.id;


--
-- Name: friday_slack_events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.friday_slack_events (
    event_id character varying(128) NOT NULL,
    team_id character varying(32) NOT NULL,
    app_id character varying(32) NOT NULL,
    channel_id character varying(32) NOT NULL,
    owner_id character varying(32) NOT NULL,
    event_ts character varying(40) NOT NULL,
    thread_ts character varying(40) NOT NULL,
    message text NOT NULL,
    state character varying(32) NOT NULL,
    reply text,
    reply_ts character varying(40),
    error_code character varying(64),
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


--
-- Name: llm_calls; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.llm_calls (
    id integer NOT NULL,
    "timestamp" timestamp without time zone NOT NULL,
    agent_id character varying(64),
    model_slug character varying(128),
    input_tokens integer,
    output_tokens integer,
    cost_usd double precision,
    success boolean
);


--
-- Name: llm_calls_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.llm_calls_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: llm_calls_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.llm_calls_id_seq OWNED BY public.llm_calls.id;


--
-- Name: messages id; Type: DEFAULT; Schema: comms; Owner: -
--

ALTER TABLE ONLY comms.messages ALTER COLUMN id SET DEFAULT nextval('comms.messages_id_seq'::regclass);


--
-- Name: agent_trust id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_trust ALTER COLUMN id SET DEFAULT nextval('public.agent_trust_id_seq'::regclass);


--
-- Name: audit_events id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_events ALTER COLUMN id SET DEFAULT nextval('public.audit_events_id_seq'::regclass);


--
-- Name: llm_calls id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.llm_calls ALTER COLUMN id SET DEFAULT nextval('public.llm_calls_id_seq'::regclass);


--
-- Data for Name: messages; Type: TABLE DATA; Schema: comms; Owner: -
--

COPY comms.messages (id, conversation_id, channel, role, sender, content, created_at) FROM stdin;
1	slack:T0CDJH2PRQT:C0CDQCBMEJJ:1793438358.737289	slack	user	U0CDQJDCMB4	AI Suggest a three-step plan for preparing an internal meeting agenda. Keep it under 70 words.	2026-10-31 09:19:19.690387+00
2	slack:T0CDJH2PRQT:C0CDQCBMEJJ:1793438358.737289	slack	assistant	friday-operations	To prepare an internal meeting agenda, first identify key topics and objectives based on current priorities. Second, allocate time slots and assign presenters or discussion leads for each topic. Third, circulate the draft agenda to participants for feedback and finalize it before the meeting. This plan assumes you have clarity on meeting goals and participant roles; if not, gather that info first.	2026-10-31 09:19:23.540892+00
\.


--
-- Data for Name: agent_trust; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.agent_trust (id, agent_id, action_type, clean_approvals, auto_approve, updated_at) FROM stdin;
\.


--
-- Data for Name: approvals; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.approvals (id, agent_id, invocation_id, action_type, title, task, context, status, approver, note, created_at, resolved_at) FROM stdin;
\.


--
-- Data for Name: audit_events; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.audit_events (id, "timestamp", event_type, agent_id, invocation_id, payload, notes) FROM stdin;
1	2026-10-30 23:43:20.691431	agent.invoke.start	friday-operations	b918a017-b4a1-4827-93ed-702bad5a79fb	{"task": "This is a synthetic local test. I have 30 minutes to write an internal meeting agenda and review my own task list. Suggest a three-step plan in under 70 words. Identify yourself as Friday and state whether you accessed external business systems or performed any actions.", "context": {"test": "synthetic"}}	\N
2	2026-10-30 23:43:22.84389	agent.invoke.error	friday-operations	b918a017-b4a1-4827-93ed-702bad5a79fb	{"error_type": "RuntimeError"}	\N
3	2026-10-30 23:44:51.412533	agent.invoke.start	friday-operations	bbff6225-264c-47e8-97e6-ab03fff66fda	{"task": "This is a synthetic local test. I have 30 minutes to write an internal meeting agenda and review my own task list. Suggest a three-step plan in under 70 words. Identify yourself as Friday and state whether you accessed external business systems or performed any actions.", "context": {"test": "synthetic"}}	\N
4	2026-10-30 23:44:53.707685	agent.invoke.error	friday-operations	bbff6225-264c-47e8-97e6-ab03fff66fda	{"error_type": "RuntimeError"}	\N
5	2026-10-30 23:45:54.016041	agent.invoke.start	friday-operations	582f99b7-be40-4da5-9b8c-2c14232fe0dd	{"task": "This is a synthetic local test. I have 30 minutes to write an internal meeting agenda and review my own task list. Suggest a three-step plan in under 70 words. Identify yourself as Friday and state whether you accessed external business systems or performed any actions.", "context": {"test": "synthetic"}}	\N
6	2026-10-30 23:45:56.58032	agent.invoke.error	friday-operations	582f99b7-be40-4da5-9b8c-2c14232fe0dd	{"error_type": "RuntimeError"}	\N
7	2026-10-30 23:46:58.57446	agent.invoke.start	friday-operations	7fe9312f-a9c9-4d8f-9ac6-d225da34eed1	{"task": "This is a synthetic local test. I have 30 minutes to write an internal meeting agenda and review my own task list. Suggest a three-step plan in under 70 words. Identify yourself as Friday and state whether you accessed external business systems or performed any actions.", "context": {"test": "synthetic"}}	\N
8	2026-10-30 23:47:01.440584	agent.invoke.error	friday-operations	7fe9312f-a9c9-4d8f-9ac6-d225da34eed1	{"error_type": "RuntimeError"}	\N
9	2026-10-30 23:57:41.012897	foundation.retry.authorized	friday-operations	\N	{"reason": "User confirmed credits added and requested resuming Milestone 4", "previous_daily_cap_usd": 0.05, "temporary_daily_cap_usd": 0.06, "additional_reserved_budget_usd": 0.01, "preserve_prior_failures": true, "model": "openai/gpt-4.1-mini"}	\N
10	2026-10-30 23:57:44.790997	agent.invoke.start	friday-operations	2686b872-0c99-4480-8016-bea00a34d103	{"task": "This is a synthetic local test. I have 30 minutes to write an internal meeting agenda and review my own task list. Suggest a three-step plan in under 70 words. Identify yourself as Friday and state whether you accessed external business systems or performed any actions.", "context": {"test": "synthetic"}}	\N
11	2026-10-30 23:57:48.522999	agent.invoke.complete	friday-operations	2686b872-0c99-4480-8016-bea00a34d103	{"result_preview": "This is Friday. I have not accessed any external business systems or performed any actions.\\n\\nThree-step plan for your 30-minute task:\\n1. Quickly list key topics and objectives for the internal meeting agenda (10 minutes).\\n2. Review your current task list, prioritize by urgency and impact (10 minutes).\\n3. Draft the agenda and update your task list notes for clarity and next steps (10 minutes).\\n\\nAssumptions: You have your task list and meeting context readily available. Uncertainty: Specific meeti"}	\N
12	2026-10-30 23:58:21.871035	foundation.retry.limit_restored	friday-operations	\N	{"daily_cap_usd": 0.05, "successful_run_cost_usd": 0.0003436, "ledger_total_including_failed_reservations_usd": 0.0503436, "prior_records_preserved": true, "local_api_stopped": true}	\N
13	2026-10-31 09:19:19.692379	chat.message	friday-operations	cc992db1-8968-4bdc-8021-9306e7fd4cc8	{"channel": "slack", "conversation_id": "slack:T0CDJH2PRQT:C0CDQCBMEJJ:1793438358.737289", "sender": "U0CDQJDCMB4", "text_length": 94, "routed_to": null}	\N
14	2026-10-31 09:19:23.541789	chat.reply	friday-operations	cc992db1-8968-4bdc-8021-9306e7fd4cc8	{"channel": "slack", "reply_length": 400}	\N
15	2026-10-31 09:19:23.801416	slack.reply.delivered	friday-operations	\N	{"event_id": "Ev0CDW6SLCRJ", "reply_ts": "1793438363.692849"}	\N
\.


--
-- Data for Name: friday_slack_events; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.friday_slack_events (event_id, team_id, app_id, channel_id, owner_id, event_ts, thread_ts, message, state, reply, reply_ts, error_code, created_at, updated_at) FROM stdin;
Ev0CDW6SLCRJ	T0CDJH2PRQT	A0CDUGGE8S0	C0CDQCBMEJJ	U0CDQJDCMB4	1793438358.737289	1793438358.737289	AI Suggest a three-step plan for preparing an internal meeting agenda. Keep it under 70 words.	delivered	To prepare an internal meeting agenda, first identify key topics and objectives based on current priorities. Second, allocate time slots and assign presenters or discussion leads for each topic. Third, circulate the draft agenda to participants for feedback and finalize it before the meeting. This plan assumes you have clarity on meeting goals and participant roles; if not, gather that info first.	1793438363.692849	\N	2026-10-31 09:19:19.226746	2026-10-31 09:19:23.798374
\.


--
-- Data for Name: llm_calls; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.llm_calls (id, "timestamp", agent_id, model_slug, input_tokens, output_tokens, cost_usd, success) FROM stdin;
2	2026-10-30 23:43:20.706361	friday-operations	openai/gpt-4.1-mini	0	0	0.01	f
3	2026-10-30 23:44:09.302422	friday-operations	openai/gpt-4.1-mini	0	0	0.01	f
4	2026-10-30 23:44:51.429797	friday-operations	google/gemma-4-31b-it:free	0	0	0.01	f
5	2026-10-30 23:45:54.032582	friday-operations	liquid/lfm-2.5-2.6b:free	0	0	0.01	f
6	2026-10-30 23:46:58.593063	friday-operations	liquid/lfm-2.5-2.6b:free	0	0	0.01	f
7	2026-10-30 23:57:44.810705	friday-operations	openai/gpt-4.1-mini	339	130	0.0003436	t
8	2026-10-31 09:19:19.706176	friday-operations	openai/gpt-4.1-mini	369	85	0.0002836	t
\.


--
-- Name: messages_id_seq; Type: SEQUENCE SET; Schema: comms; Owner: -
--

SELECT pg_catalog.setval('comms.messages_id_seq', 2, true);


--
-- Name: agent_trust_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.agent_trust_id_seq', 1, false);


--
-- Name: audit_events_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.audit_events_id_seq', 15, true);


--
-- Name: llm_calls_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.llm_calls_id_seq', 8, true);


--
-- Name: messages messages_pkey; Type: CONSTRAINT; Schema: comms; Owner: -
--

ALTER TABLE ONLY comms.messages
    ADD CONSTRAINT messages_pkey PRIMARY KEY (id);


--
-- Name: agent_trust agent_trust_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_trust
    ADD CONSTRAINT agent_trust_pkey PRIMARY KEY (id);


--
-- Name: approvals approvals_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.approvals
    ADD CONSTRAINT approvals_pkey PRIMARY KEY (id);


--
-- Name: audit_events audit_events_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_events
    ADD CONSTRAINT audit_events_pkey PRIMARY KEY (id);


--
-- Name: friday_slack_events friday_slack_events_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.friday_slack_events
    ADD CONSTRAINT friday_slack_events_pkey PRIMARY KEY (event_id);


--
-- Name: friday_slack_events friday_slack_events_team_id_channel_id_event_ts_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.friday_slack_events
    ADD CONSTRAINT friday_slack_events_team_id_channel_id_event_ts_key UNIQUE (team_id, channel_id, event_ts);


--
-- Name: llm_calls llm_calls_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.llm_calls
    ADD CONSTRAINT llm_calls_pkey PRIMARY KEY (id);


--
-- Name: idx_comms_messages_conv; Type: INDEX; Schema: comms; Owner: -
--

CREATE INDEX idx_comms_messages_conv ON comms.messages USING btree (conversation_id, id DESC);


--
-- Name: ix_agent_trust_agent_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_agent_trust_agent_id ON public.agent_trust USING btree (agent_id);


--
-- Name: ix_approvals_action_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_approvals_action_type ON public.approvals USING btree (action_type);


--
-- Name: ix_approvals_agent_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_approvals_agent_id ON public.approvals USING btree (agent_id);


--
-- Name: ix_approvals_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_approvals_status ON public.approvals USING btree (status);


--
-- Name: ix_audit_events_agent_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_audit_events_agent_id ON public.audit_events USING btree (agent_id);


--
-- Name: ix_audit_events_event_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_audit_events_event_type ON public.audit_events USING btree (event_type);


--
-- Name: ix_audit_events_invocation_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_audit_events_invocation_id ON public.audit_events USING btree (invocation_id);


--
-- Name: ix_audit_events_timestamp; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_audit_events_timestamp ON public.audit_events USING btree ("timestamp");


--
-- Name: ix_llm_calls_agent_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_llm_calls_agent_id ON public.llm_calls USING btree (agent_id);


--
-- Name: ix_llm_calls_timestamp; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_llm_calls_timestamp ON public.llm_calls USING btree ("timestamp");


--
-- PostgreSQL database dump complete
--

